﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace checkbox_control
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Handelcheck(object sender ,RoutedEventArgs e)
        {
            CheckBox cb =sender as CheckBox;
            if (cb.Name == "checkbox1") Textbox1.Text = "2 state checkbox is checked";
            else Textbox2.Text = "3 state checkbox unchecked";
        }


        private void Handeluncheck(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            if (cb.Name == "checkbox1") Textbox1.Text = "2 state checkbox is checked";
            else Textbox2.Text = "3 state checkbox unchecked";
        }

        private void Handelthirdstate(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
           
            Textbox2.Text = "3 state checkbox unchecked";
        }

        private void Combo_selectionchanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (ComboBox.SelectedItem != null)
            {
                Textbox3.Text = ComboBox.SelectedItem.ToString();
            }
        }

        private void Combo1_selectionchanged(object sender, SelectionChangedEventArgs e)
        {
           
            if (ComboBox1.SelectedItem != null)
            {
                Textbox4.Text = ComboBox1.SelectedItem.ToString();
            }
        }
    }
}
